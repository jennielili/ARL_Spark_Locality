""" Pipeline support functions

"""

import logging

log = logging.getLogger(__name__)


def import_pipeline_parameters(**kwargs):
    """ Import parameters to pipelines
    
    Placeholder
     
    :param params: Dictionary containing parameters
    :return:
   """
    # TODO: implement
    pass


def export_pipeline_log(**kwargs):
    """ Export pipeline log
    
    Place-holder
   
    :param params: Dictionary containing parameters
    :return:
    """
    # TODO: implement
    pass
